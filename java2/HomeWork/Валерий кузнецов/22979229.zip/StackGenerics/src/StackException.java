
public class StackException extends Exception{
}
