package finance;


public interface DataStore {

}
