package j2l1;


public class StackException extends Exception{
  
    
    public String toString() {
        return "\n StackException ";
    }
    
    
}
