package ru.java2.lesson1;

/**
 * Created by Abilis on 04.04.2016.
 */
public class StackException extends Exception {




}
