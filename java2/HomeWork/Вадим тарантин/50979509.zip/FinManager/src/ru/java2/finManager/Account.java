package ru.java2.finManager;


import java.util.Set;

/**
 * Created by Abilis on 04.04.2016.
 */
public class Account {

    private String description;
    private int ostatok;
    private Set<Record> setOfRecords;

}
