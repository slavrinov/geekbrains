package ru.java2.finManager;

/**
 * Created by Abilis on 04.04.2016.
 */
public class User {

    private String login;
    private String password;


}
