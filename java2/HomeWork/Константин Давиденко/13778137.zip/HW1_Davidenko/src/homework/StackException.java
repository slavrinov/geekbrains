package homework;

public class StackException extends Exception {

    public StackException() {
        super();
    }

    public StackException(String message) {
        super(message);
    }
}
