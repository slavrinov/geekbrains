package lesson4;

/**
 * Created on 13/08/14.
 */
public interface Strategy {
    public String algorithm(String str);
}
