package lesson7;


public interface Gear {
    void setGear(int gear);
    void nextGear();
}
