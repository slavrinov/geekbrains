package lesson7.di;

/**
 *
 */
public class InvalidConfigurationException extends Exception {
    public InvalidConfigurationException(String msg) {
        super(msg);
    }
}
