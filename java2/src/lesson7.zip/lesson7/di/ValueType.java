package lesson7.di;

/**
 *
 */
public enum ValueType {
    VALUE,
    REF
}
