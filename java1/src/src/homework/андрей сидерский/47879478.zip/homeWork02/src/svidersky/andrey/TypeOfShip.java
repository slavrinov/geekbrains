package svidersky.andrey;

/**
 * Created by User1 on 06.04.2016.
 */
public enum TypeOfShip
{
    ONE,TWO,THREE,FOUR
}
